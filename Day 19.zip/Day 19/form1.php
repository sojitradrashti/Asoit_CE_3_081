<?php
$servername="localhost";
$username="root";
$password="";
$databasename="student information";

$conn = mysqli_connect($servername,$username,$password,$databasename);
if($conn->connect_error)
{
    die($conn->connect_error);
}
else
{
    echo "Mysql connected successfully";
}

$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$enroll=$_REQUEST['enroll'];
$branch=$_REQUEST['branch'];
$semester=$_REQUEST['semester'];
$divison=$_REQUEST['divison'];
$Mno=$_REQUEST['Mno'];
$city=$_REQUEST['city'];

$sql="INSERT INTO student1 VALUES('$fname','$lname','$enroll','$branch','$semester','$divion','$Mno','$city')";
if(mysqli_query($conn,$sql))
{
    echo "successfully save.";
}
else{
    echo "ERROR $sql. "
    .mysqli_error($conn);
}
mysqli_close($conn);
?>
