<!DOCTYPE html>
<html>
    <head>
        <title>Student Registration Form</title>
</head>
<body>
<form action="form1.php" method="post">
    <center>
    <h1>Student Registration Form</h1>
    <lable>First Name:</lable>
    <input type="text" name="fname"><br><br>
    <lable>Last Name:</lable>
    <input type="text" name="lname"><br><br>
    <lable>Enrollment no:</lable>
    <input type="text" name="enroll"><br><br>
    <lable>Branch:</lable>
    <input type="text" name="branch"><br><br>
    <lable>semester:</lable>
    <input type="text" name="semester"><br><br>
    <lable>Divison:</lable>
    <input type="text" name="divison"><br><br>
    <lable>Mobile no:</lable>
    <input type="text" name="Mno"><br><br>
    <lable>City:</lable>
    <input type="text" name="city"><br><br>
    <input type="submit" value="submit">
</center>
</body>
</html>
