<?php
$server="localhost";
$username="root";
$password="";
$databasename="sou";

$conn= mysqli_connect($server,$username,$password,$databasename);
if($conn->connect_error){
    die("connection failed:".$conn->connect_error);
}
echo "connected successfully";
?>
