<!DOCTYPE html>
<html>

<head>
	<title>Feedback form</title>
	<meta charset="utf-8">
	<meta name="viewport"
		content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js">
	</script>
	<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js">
	</script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js">
	</script>
	<style>
		form {
			box-shadow: 10px 10px 40px black;
			padding: 50px;
			margin: 20px;
			background-img:url("silver.png");
			
			
		}
		
	</style>
</head>

<body>

	
	<form>
			
		<h1 class="text-success text-center">
			Feedback Form
		</h1>
		
		<!-- <h5 class="text-success text-center">
			Sending email with a
			file attachment
		</h5> -->
		
		<div class="form-group">
			<input type="text" name="name"
				class="form-control"
				placeholder="Name" required="">
		</div>
		<div class="form-group">
			<input type="number" name="enroll"
				class="form-control"
				placeholder="Email address" required="">
		</div>

		<div class="form-group">
			<input type="email" name="email"
				class="form-control"
				placeholder="Designation" required="">
		</div>
		
		<div class="form-group">
			<textarea type="text" name="feedback_write" placeholder="Feedback Write..." cols="30" rows="3"></textarea>
		</div>
		<div class="submit text-center">
			<input type="submit" name="submit"
				class="btn btn-success "
				value="Submit">
		</div>
	</form>
</body>

</html>
