<!DOCTYPE html>
<html>
<head>
<title>FEEDBACK FORM</title>
</head>

<style>

*{
box-sizing:border-box;
}

input[type=text], select, textarea{
width : 100%;
padding : 12px;
border:1px solid grb(70,68,68);
border-radius : 4px;
resize : vertical;
}

input[type=email], select, textarea{
width:100%;
padding:12px;
border:1px solid grb(70,68,68);
border-radius:4px;
resize:vertical;
}

label{
padding:12px 12px 12px 0;
display:inline-block;
}

input[type=submit]{
background-color: rgb(37,116,161);
color:grey;
padding:12px 20px;
border:none;
border-radius:4px;
cursor:pointer;
float:right;
} 

input[type=submit]:hover{
background-color:#45a049;
}

.container{
border-radius:5px;
padding:20px;
}

.col-25{
float:left;
width:25%;
margin-top:6px;
}

.col-75{
float:left;
width:75%;
margin-top:6px;
}

.row-after{
content: "";
display:table;
clear:both;
}

</style>

<body>
    <form action="feedback_form1.php" method="post">
<center>
<h3>Feedback Form</h3>
</center>
<div class="container">
<div class="row">
<div class="col-25">
<label for="fname">First Name</label>
</div>
<div class="col-75">
<input type="text" name="fname" placeholder="Enter your first name" required>
</div>
</div>
<br>

<div class="row">
    <div class="col-25">
<label for="lname">Last Name</label>
</div>
<div class="col-75">
<input type="text" name="lname" placeholder="Enter your last name" required>
</div>
</div>
<br>

<div class="row">
<div class="col-25">
<label for="email">Email</label>
</div>
<div class="col-75">
<input type="email" name="email" placeholder="Enter your email" required>
</div>
</div>
<br>

<div class="row">
<div class="col-25">
<label for="feedback">Feed Back</label>
</div>
<br>
<br>
<div class="col-75">
<textarea  name="feedback" placeholder="Write something......." style="height:200px" required>
</textarea>
</div>
</div>
<br>
<center>
<div class="row">
<input type="submit" value="submit" >
</div></center>

</form>
</body>
</html>