<?php
$servername="localhost";
$username="root";
$password="";
$databasename="sou";

$conn = mysqli_connect($servername,$username,$password,$databasename);
if($conn->connect_error)
{
    die($conn->connect_error);
}
else
{
    echo "Mysql connected successfully";
}

$fname=$_REQUEST['fname'];
$lname=$_REQUEST['lname'];
$email=$_REQUEST['email'];
$feedback=$_REQUEST['feedback'];
$sql="INSERT INTO feedback1 VALUES('$fname','$lname','$email','$feedback')";
if(mysqli_query($conn,$sql))
{
    echo "successfully save.";
}
else{
    echo "ERROR $sql. "
    .mysqli_error($conn);
}
mysqli_close($conn);
?>